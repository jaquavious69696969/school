class Tank {
  float x, w, h, speed, health;
  PImage tank

  // constucter
  Tank() {
    x = 100.0;
    w = 100.0;
    h = 100.0;
    speed = 20.0;
    health = 3.0;
    tank = loadImage("tank.png");
  }


  void move(char dir) {
    if (dir == 'a') {
      x = x + speed;
    } else  if (dir == 'd') {
      x = x - speed;
  } 
}
}
