class Projectile {
  float x, y, w, h, speed;

  // constucter
  Projectile(int x, int y) {
    this.x = x;
    this.y = y;
    w = 7;
    h = 10;
    speed = 500;
  }

  void display() {
    rectMode(CENTER);
    rect(x, y, w, h);
  }
  void move(int x, int y) {
    y = y - speed;
  }
