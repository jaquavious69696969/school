PImage bg;
Tank tank1;
int score;
ArrayList<Obstacle> obstacles = new ArrayList<Obstacle>();
ArrayList<Projectile> projectiles = new ArrayList<Projectile>();
Timer obsTimer;


void setup() {
  size(500, 500);
  bg = loadImage("bg.png");
  tank1 = new Tank();
  if (obsTimer.ifFinished()) {
   obstacles.add(new Obstacle(-100, int(random(height)))); 
  }
  //obstacles.add(new Obstacle(250, 300));
  //obstacles.add(new Obstacle(250, 200));
  score = 0;
  obsTimer = new Timer(500);
}

void draw() {
  background(127);
  imageMode(CORNER);
  image(bg, 0, 0);
  tank1.display();
  for (int i = 0; i < obstacles.size(); i++) {
    Obstacle obs = obstacles.get(i);
    obs.display();
    obs.move();
  }
}

void scorePanel() {
  fill(127, 127);
  rectMode(CENTER);
  rect(width/2, 30, width, 60);
  fill(255);
  textSize(30);
  textAlign(CENTER);
  text("score:", width/2, 50);
}

void keyPressed() {
  if (key == 'a') {
    tank1.move('a');
  } else if (key == 'd') {
    tank1.move('d');
}
}

void mousePressed() {
  projectiles.add(new projectiles(tank1.x,tank1.y));
}
