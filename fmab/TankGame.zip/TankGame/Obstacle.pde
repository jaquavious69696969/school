class Obstacle {
  float x, y, w, h, speed, health;
  PImage obstacle1;

  // constucter
  Obstacle(int x, int y) {
    this.x = x;
    this.y = y;
    w = 100;
    h = 100;
    speed = 2;
    health = 10;
    obstacle1 = loadImage("rok.png");
  }

  void display() {
    imageMode(CENTER);
    image(obstacle1, x, y);
  }
  void move() {
    x = x + speed;
    if (x> width) {
      x = 0;
    }
  }
}
